
--
-- Zrzut danych tabeli `image`
--

INSERT INTO `image` (`ID_IMAGE_PK`, `ID_PROPERTY_FK`, `IMAGE_FILE`, `IMAGE_TITLE`, `IMAGE_SIZE`, `IMAGE_TIME`) VALUES
(1, 1, '_upload/powuz_01.jpg', 'powuz_01.jpg', 218.16, '2017-02-13 10:10:57'),
(2, 1, '_upload/powuz_02.jpg', 'powuz_02.jpg', 186.75, '2017-02-13 10:10:58'),
(3, 4, '_upload/dom_04kopia.jpg', 'dom_04kopia.jpg', 301.75, '2017-02-15 11:16:09'),
(4, 4, '_upload/dom_04.jpg', 'dom_04.jpg', 301.75, '2017-02-15 11:16:09'),
(5, 5, '_upload/Mieszkanie Kraków/mieszkania_03.jpg', 'mieszkania_03.jpg', 101.64, '2017-02-18 13:17:26'),
(6, 5, '_upload/Mieszkanie Kraków/mieszkania_05.jpg', 'mieszkania_05.jpg', 224.52, '2017-02-18 13:17:35'),
(17, 11, '_upload/1/dzialka_02.jpg', 'dzialka_02.jpg', 275.35, '2017-02-18 14:04:45'),
(18, 11, '_upload/1/dzialka_03.jpg', 'dzialka_03.jpg', 149.45, '2017-02-18 14:04:45');
