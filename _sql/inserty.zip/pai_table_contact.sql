
--
-- Zrzut danych tabeli `contact`
--

INSERT INTO `contact` (`ID_CONTACT_PK`, `ID_USER_FK`, `CONTACT_EMAIL`, `CONTACT_PHONE`) VALUES
(60, 3, 'nel@o2.pl', '123-123-123'),
(61, 2, 'test@o2.pl', '321-321-312'),
(80, 4, 'kowalski@o2.pl', '788-888-777'),
(81, 1, 'admin@mail.pl', '555-555-555'),
(103, 41, 'chmura@o2.pl', '444-444-444'),
(105, 43, 'wysocka@wp.pl', '433-334-434'),
(109, 47, 'miki@o2.pl', '112-222-222'),
(110, 48, 'eliza@o2.pl', '783-342-652'),
(111, 49, 'donald@o2.pl', '456-347-126'),
(112, 50, 'ikea@o2.pl', '345-663-546');
