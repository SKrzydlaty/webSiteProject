
--
-- Zrzut danych tabeli `city`
--

INSERT INTO `city` (`id_city_pk`, `city_title`) VALUES
(1, 'Andrychów'),
(12, 'Inwałd'),
(2, 'Kalwaria Zebrzydowska'),
(3, 'Kraków'),
(4, 'Wadowice'),
(5, 'Żywiec');
